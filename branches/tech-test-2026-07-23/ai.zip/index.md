# Übersicht - MII IG Kerndatensatz-Modul Metadaten Provenance v0.2.0-rc.1

* [**Table of Contents**](toc.md)
* **Übersicht**

## Übersicht

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-metadaten-provenance/ImplementationGuide/mii-ig-metadaten-provenance-de-v2026 | *Version*:0.2.0-rc.1 |
| Draft as of 2026-07-23 | *Computable Name*:MII_IG_Metadaten_Provenance_DE |

Dieses Dokument beschreibt Konzepte und Implementierungsalternativen zur Unterstützung einer basalen Provenance im MII-Kerndatensatz. Es dient als informativer Beitrag zur Diskussion innerhalb der Medizininformatik-Initiative und stellt keine verbindliche Festlegung dar.

| | |
| :--- | :--- |
| Datum | 2025-02-16 |
| Version | 0.1.0 |
| Status | Entwurf (informativ) |
| Realm | DE |

### Leitmotiv: Von der Dokumentation zur Aktion

> **Metadaten, die Datenqualität nicht nur beschreiben, sondern operativ steuerbar machen – umsetzbar mit einer Zeile Code (`Meta.tag`) oder als begleitende Ressourceninfrastruktur (`FHIR Provenance`).**

Provenance-Metadaten im MII-Kerndatensatz sind mehr als passive Dokumentation. Sie sind der operative Ankerpunkt, um Datenqualitätsprobleme systematisch zu **erkennen**, zu **lokalisieren** und zu **beheben**:

1. **Beschreiben**– Woher stammen die Daten? Welches Quellsystem, welche ETL-Strecke, welches Datenmodell?
1. **Erkennen**– Welche Probleme haben die Daten? Duplikate, fehlende Werte, Widersprüche zwischen Quellen?
1. **Handeln**– Gezielte Abfragen und Korrekturen auf Basis der Metadaten: alle oBDS-Importe mit logischen Widersprüchen filtern, alle Duplikate eines Zeitraums identifizieren, fehlerhafte ETL-Läufe gezielt nachtransformieren.

Die MII Taskforce Metadaten verbindet dabei wissenschaftliche Grundlagen (Dublin Core, W3C PROV, Greifswalder DQ-Framework) mit der operativen Realität in den Datenintegrationszentren.

**Voraussetzung:** Damit Metadaten actionable sind, müssen sie nicht nur **setzbar** (**settable**), sondern auch **abfragbar** (**retrievable**) sein. Metadaten, die zwar geschrieben, aber nicht über Suchparameter gefunden werden können, verlieren ihren operativen Nutzen. Dies ist eine reale Einschränkung: Bei bestimmten FHIR-Server-Konfigurationen (z.B. HAPI FHIR im INLINE-Modus) ist die `_tag`-Suche standardmäßig nicht verfügbar (siehe [Verhalten von Meta.tag auf FHIR-Servern](ansatz-metatag.md#verhalten-von-metatag-auf-fhir-servern)). Die Wahl des Ansatzes hängt daher auch von der **vorhandenen Infrastruktur** ab.

### Zielsetzung

Versorgungsdaten unterscheiden sich in vielen Punkten von prospektiven Datensammlungen. Diese Unterschiede müssen ausgedrückt werden können, um korrekte Auswertungen zu ermöglichen. Dieses Dokument stellt zwei technische Ansätze zur Provenance-Auszeichnung gegenüber:

1. **Meta.tag-Ansatz**– leichtgewichtige Auszeichnung über kontrollierte Vokabulare in`Resource.meta.tag`(Taskforce Metadaten, Löbe et al.). Pragmatisch, sofort implementierbar, mit einer Zeile Code pro Aussage. Setzt voraus, dass der FHIR-Server die`_tag`-Suche unterstützt.
1. **FHIR Provenance Ressource**– eigene Provenance-Ressourcen mit Referenzen auf Quell- und Zielressourcen (BZKF obds-to-fhir, Gulden). Strukturiert, international interoperabel, mit vollständiger Transformationskette. Unabhängig von der Tag-Konfiguration des Servers, da Provenance als reguläre Ressource gespeichert und durchsucht wird.

Beide Ansätze sind **komplementär**, nicht gegensätzlich. Welcher Ansatz (oder welche Kombination) im konkreten Fall geeignet ist, hängt von den Anforderungen an Aussagekraft, Implementierungsaufwand und der vorhandenen Server-Infrastruktur ab. Sie werden anhand konkreter Beispiele – insbesondere am [Deduplizierungsszenario in der Onkologie](anwendungsbeispiel-deduplizierung.md) mit vollständiger Ressourcen-History – beschrieben und verglichen.

### Beitragende

* MII Taskforce Metadaten (Matthias Löbe et al.) – Konzeptpapier v1.0, Juli 2025
* Christian Gulden (BZKF) – Provenance-Implementierung in obds-to-fhir
* Thomas Debertshäuser (BIH/Charité) – Redaktion und Zusammenführung

### Ansprechpartner

Fragen zu der vorliegenden Publikation können jederzeit unter [chat.fhir.org](https://chat.fhir.org) im Stream 'german/mi-initiative' gestellt werden.

Anmerkungen und Kritik in Form von 'Issues' im [GitHub-Projekt](https://github.com/medizininformatik-initiative/kerndatensatzmodul-metadaten-provenance/issues).

### Disclaimer

Dieser Leitfaden ist ein informativer Beitrag zu Spezifikationsalternativen. Er stellt keine normative Festlegung der Medizininformatik-Initiative dar.

